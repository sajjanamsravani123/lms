package com.leave.leave.service;

public interface ApproverService {

}
